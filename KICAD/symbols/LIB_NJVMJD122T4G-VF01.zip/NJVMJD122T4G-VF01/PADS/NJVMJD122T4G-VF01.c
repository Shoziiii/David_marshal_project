*PADS-LIBRARY-SCH-DECALS-V9*

NJVMJD122T4G-VF01      31900 32000 100 10 100 10 4 8 0 3 8
TIMESTAMP 2018.09.21.13.37.18
"Default Font"
"Default Font"
550   50    0 8 100 10 "Default Font"
REF-DES
550   -50   0 8 100 10 "Default Font"
PART-TYPE
550   -150  0 8 100 10 "Default Font"
*
550   -250  0 8 100 10 "Default Font"
*
CIRCLE 2 10 0 -1
400   150  
300   -150 
OPEN   2 20 0 -1
300   100  
300   -100 
OPEN   2 10 0 -1
300   50   
400   150  
OPEN   2 10 0 -1
300   -50  
400   -150 
OPEN   2 10 0 -1
400   -150 
400   -200 
OPEN   2 10 0 -1
400   150  
400   200  
COPCLS 4 10 0 -1
330   -100 
350   -80  
370   -120 
330   -100 
OPEN   2 10 0 -1
100   0    
300   0    
T0     0     0 0 0     20    0 0 0     -20   0 32 PINSHORT
P-520  0     0 2 -80   0     0 2 0
T400   -300  90 0 0     20    90 32 0     -20   90 34 PINSHORT
P-520  0     0 2 -80   0     0 2 0
T400   300   90 4 0     20    90 32 0     -20   90 34 PINSHORT
P-520  0     0 2 -80   0     0 2 0

*END*